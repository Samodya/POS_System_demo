import Topbar from "../components/topbar";

export const Reports = () => {
  return (
    <div className="w-full">
      <Topbar title={"Reports"} />
    </div>
  );
};
